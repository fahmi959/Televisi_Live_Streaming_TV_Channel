package com.fahmi.livestreamingtvchannel


data class Channel(
    val name: String,
    val videoUrl: String,
    val logoUrl: String
)